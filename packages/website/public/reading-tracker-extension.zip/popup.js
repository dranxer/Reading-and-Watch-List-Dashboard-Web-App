// Popup script for Reading Tracker Extension with Local AI
// Handles UI for Gemma-3-1b model status and content processing

class AIReadingTrackerPopup {
    constructor() {
        this.elements = {
            modelStatus: document.getElementById('modelStatus'),
            modelText: document.getElementById('modelText'),
            authStatus: document.getElementById('authStatus'),
            authText: document.getElementById('authText'),
            authMessage: document.getElementById('authMessage'),
            signInBtn: document.getElementById('signInBtn'),
            signOutBtn: document.getElementById('signOutBtn'),
            extractBtn: document.getElementById('extractBtn'),
            openDashboardBtn: document.getElementById('openDashboardBtn'),
            debugBtn: document.getElementById('debugBtn'),
            progressContainer: document.getElementById('progressContainer'),
            progressFill: document.getElementById('progressFill'),
            notification: document.getElementById('notification')
        };

        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.updateStatus();
        this.startStatusPolling();
    }

    setupEventListeners() {
        // Sign in to website
        this.elements.signInBtn.addEventListener('click', () => {
            chrome.tabs.create({ url: 'http://localhost:3000/auth-token' });
        });

        // Sign out
        this.elements.signOutBtn.addEventListener('click', async () => {
            await this.clearAuth();
            this.updateAuthStatus(false);
            this.showNotification('Signed out successfully', false);
        });

        // Extract current page
        this.elements.extractBtn.addEventListener('click', async () => {
            await this.extractCurrentPage();
        });

        // Open dashboard
        this.elements.openDashboardBtn.addEventListener('click', () => {
            chrome.tabs.create({ url: 'http://localhost:3000/dashboard' });
        });

        // Debug extension
        this.elements.debugBtn.addEventListener('click', () => {
            this.runDiagnostics();
        });

        // Listen for background messages
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleBackgroundMessage(request);
        });
    }

    async updateStatus() {
        try {
            // Get AI model status
            const modelStatus = await this.getModelStatus();
            this.updateModelStatus(modelStatus);

            // Get authentication status
            const authData = await this.getAuthData();
            this.updateAuthStatus(!!authData, authData);

        } catch (error) {
            console.error('Error updating status:', error);
            this.updateModelStatus({ isLoaded: false, isLoading: false });
            this.updateAuthStatus(false);
        }
    }

    async getModelStatus() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'getModelStatus' }, (response) => {
                resolve(response || { isLoaded: false, isLoading: false });
            });
        });
    }

    async getAuthData() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'getClerkAuth' }, (response) => {
                resolve(response?.userData || null);
            });
        });
    }

    async clearAuth() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'clearAuth' }, (response) => {
                resolve(response);
            });
        });
    }

    updateModelStatus(status) {
        const { modelStatus, modelText, progressContainer, progressFill } = this.elements;
        const statusDot = modelStatus.querySelector('.status-dot');

        if (status.isLoading) {
            modelStatus.className = 'status-indicator loading';
            statusDot.className = 'status-dot loading';
            modelText.textContent = `Loading Smart Analysis... ${Math.round((status.progress || 0) * 100)}%`;
            progressContainer.classList.remove('hidden');
            progressFill.style.width = `${(status.progress || 0) * 100}%`;
        } else if (status.isLoaded) {
            modelStatus.className = 'status-indicator ready';
            statusDot.className = 'status-dot ready';
            modelText.textContent = '🧠 Smart Analysis Ready';
            progressContainer.classList.add('hidden');
        } else {
            // Not loaded - show initialize option
            modelStatus.className = 'status-indicator warning';
            statusDot.className = 'status-dot warning';
            modelText.textContent = 'Click to Initialize';
            progressContainer.classList.add('hidden');
        }
    }

    updateAuthStatus(isAuthenticated, authData = null) {
        const { authStatus, authText, authMessage, signInBtn, signOutBtn, extractBtn } = this.elements;
        const statusDot = authStatus.querySelector('.status-dot');

        if (isAuthenticated && authData) {
            authStatus.className = 'status-indicator ready';
            statusDot.className = 'status-dot ready';
            authText.textContent = 'Signed In';
            
            const userName = `${authData.firstName || ''} ${authData.lastName || ''}`.trim() || authData.email;
            authMessage.textContent = `✅ Ready to track content as ${userName}`;
            authMessage.className = 'auth-message';
            
            signInBtn.classList.add('hidden');
            signOutBtn.classList.remove('hidden');
            extractBtn.disabled = false;
        } else {
            authStatus.className = 'status-indicator offline';
            statusDot.className = 'status-dot offline';
            authText.textContent = 'Not Signed In';
            authMessage.textContent = 'Sign in to automatically track and share high-quality content';
            authMessage.className = 'auth-message error';
            
            signInBtn.classList.remove('hidden');
            signOutBtn.classList.add('hidden');
            extractBtn.disabled = true;
        }
    }

    async extractCurrentPage() {
        try {
            this.elements.extractBtn.disabled = true;
            this.elements.extractBtn.textContent = 'Analyzing...';

            // Get current tab
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab) {
                throw new Error('No active tab found');
            }

            // Send message to content script
            await chrome.tabs.sendMessage(tab.id, { action: 'extractNow' });
            
            this.showNotification('🤖 AI analyzing content quality...', false);

        } catch (error) {
            console.error('Error extracting page:', error);
            this.showNotification('Failed to extract content. Make sure you are on an article page.', true);
        } finally {
            this.elements.extractBtn.disabled = false;
            this.elements.extractBtn.textContent = 'Extract Current Page';
        }
    }

    handleBackgroundMessage(request) {
        switch (request.action) {
            case 'modelProgress':
                this.updateProgress(request.progress, request.text);
                break;
                
            case 'modelReady':
                this.updateModelStatus({ isLoaded: true, isLoading: false });
                this.showNotification('🧠 Smart Analysis Ready! Automatic content tracking enabled.', false);
                break;
                
            case 'modelError':
                this.updateModelStatus({ isLoaded: false, isLoading: false });
                this.showNotification('❌ Smart analysis failed to initialize.', true);
                break;
                
            case 'contentSaved':
                const publicText = request.isPublic ? ' • Added to public list!' : '';
                this.showNotification(`✅ High-quality content saved! (${request.rating}/10)${publicText}`, false);
                break;
                
            case 'contentSkipped':
                this.showNotification(`⚠️ Content quality too low (${request.rating}/10): ${request.reason}`, true);
                break;
                
            case 'authRequired':
                this.showNotification('Please sign in to save content', true);
                break;
                
            case 'processingError':
                this.showNotification(`❌ Processing failed: ${request.error}`, true);
                break;
                
            case 'authSuccess':
                this.showNotification('✅ Successfully authenticated!', false);
                setTimeout(() => this.updateStatus(), 500);
                break;
        }
    }

    updateProgress(progress, text) {
        const { progressContainer, progressFill, modelText } = this.elements;
        
        if (progress !== undefined) {
            progressContainer.classList.remove('hidden');
            const percentage = Math.round(progress * 100);
            progressFill.style.width = `${percentage}%`;
            if (text) {
                modelText.textContent = `${text} ${percentage}%`;
            }
        } else {
            progressContainer.classList.add('hidden');
        }
    }

    showNotification(message, isError = false) {
        const { notification } = this.elements;
        
        notification.textContent = message;
        notification.className = `notification ${isError ? 'error' : 'success'}`;
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 4000);
    }

    async initializeAI() {
        try {
            this.showNotification('🧠 Initializing smart content analysis...', false);
            this.updateModelStatus({ isLoading: true, progress: 0 });
            
            chrome.runtime.sendMessage({ action: 'initializeAI' }, (response) => {
                if (response?.success) {
                    this.showNotification('🧠 Smart analysis initialized successfully!', false);
                } else {
                    this.showNotification('❌ Failed to initialize smart analysis', true);
                }
            });
        } catch (error) {
            this.showNotification('❌ Initialization error', true);
        }
    }

    runDiagnostics() {
        console.log('🔧 Running extension diagnostics...');
        
        // Test background communication
        chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
            if (response) {
                console.log('✅ Background script communication working:', response);
                this.showNotification(`✅ Extension working (Analysis: ${response.aiLoaded ? 'Ready' : 'Not loaded'})`, false);
            } else {
                console.log('❌ Background script not responding');
                this.showNotification('❌ Background script not responding', true);
            }
        });
    }

    startStatusPolling() {
        // Update status every 5 seconds
        setInterval(() => {
            this.updateStatus();
        }, 5000);
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AIReadingTrackerPopup();
});

// Handle model status click to initialize AI
document.addEventListener('click', (event) => {
    if (event.target.closest('#modelStatus')) {
        const popup = new AIReadingTrackerPopup();
        popup.initializeAI();
    }
}); 