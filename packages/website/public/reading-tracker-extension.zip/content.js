/* eslint-disable no-undef */
// Content script for Reading Tracker Extension
// This script runs on every page and extracts article content when appropriate

let isProcessing = false;
let lastProcessedUrl = null;

// Check if this page is likely to contain an article
function isArticlePage() {
  // Skip if already processing or if URL hasn't changed
  if (isProcessing || lastProcessedUrl === window.location.href) {
    return false;
  }

  // Skip certain page types (but allow YouTube for video tracking and localhost for testing)
  const skipPatterns = [
    /^https?:\/\/(www\.)?(google|facebook|twitter|instagram|linkedin)\./,
    /^https?:\/\/.*\.(pdf|doc|docx|ppt|pptx|xls|xlsx)$/,
    /^https?:\/\/.*\/search\?/,
    /^https?:\/\/.*\/login/,
    /^https?:\/\/.*\/signin/,
    /^https?:\/\/.*\/admin/
  ];

  for (const pattern of skipPatterns) {
    if (pattern.test(window.location.href)) {
      return false;
    }
  }

  // Check for video content (YouTube, Vimeo, etc.)
  const url = window.location.href.toLowerCase();
  const isVideoPage = 
    (url.includes('youtube.com/watch') && url.includes('v=')) ||
    (url.includes('vimeo.com/') && /vimeo\.com\/\d+/.test(url)) ||
    (url.includes('dailymotion.com/video/')) ||
    (url.includes('twitch.tv/videos/'));

  if (isVideoPage) {
    return true; // Always process video pages
  }

  // Check for article indicators
  const articleIndicators = [
    'article',
    'post',
    'blog',
    'story',
    'news',
    'tutorial',
    'guide',
    'how-to'
  ];

  const title = document.title.toLowerCase();
  const hasArticleIndicator = articleIndicators.some(indicator => 
    url.includes(indicator) || title.includes(indicator)
  );

  // Check for article-like content structure
  const hasArticleContent = document.querySelector('article, .post, .blog-post, .story, .content, .entry');
  const hasSubstantialText = document.body.textContent.trim().length > 1000;

  return hasArticleIndicator || hasArticleContent || hasSubstantialText;
}

// Extract video information
function extractVideoInfo() {
  const url = window.location.href;
  let videoInfo = {
    url: url,
    title: document.title,
    type: 'VIDEO',
    textContent: '',
    excerpt: '',
    siteName: '',
    byline: ''
  };

  if (url.includes('youtube.com/watch')) {
    // YouTube video extraction
    const titleElement = document.querySelector('h1.ytd-video-primary-info-renderer, h1.ytd-watch-metadata');
    const descriptionElement = document.querySelector('#description, #watch-description-text, #meta-contents #description');
    const channelElement = document.querySelector('#channel-name a, .ytd-channel-name a');
    
    videoInfo.title = titleElement?.textContent?.trim() || document.title;
    videoInfo.textContent = descriptionElement?.textContent?.trim() || '';
    videoInfo.byline = channelElement?.textContent?.trim() || '';
    videoInfo.siteName = 'YouTube';
    videoInfo.excerpt = videoInfo.textContent.substring(0, 200);
  } else if (url.includes('vimeo.com')) {
    // Vimeo video extraction
    const titleElement = document.querySelector('[data-name="Header"] h1, .player_title');
    const descriptionElement = document.querySelector('[data-name="Description"], .description');
    const creatorElement = document.querySelector('[data-name="PortraitByline"] a, .byline a');
    
    videoInfo.title = titleElement?.textContent?.trim() || document.title;
    videoInfo.textContent = descriptionElement?.textContent?.trim() || '';
    videoInfo.byline = creatorElement?.textContent?.trim() || '';
    videoInfo.siteName = 'Vimeo';
    videoInfo.excerpt = videoInfo.textContent.substring(0, 200);
  }

  return videoInfo;
}

// Extract article content using Readability
async function extractArticleContent() {
  if (isProcessing) {
    console.log("⏳ Content extraction already in progress, skipping...");
    return;
  }
  
  try {
    isProcessing = true;
    lastProcessedUrl = window.location.href;

    console.log("🔄 Attempting to extract content from:", window.location.href);

    // Check if this is a video page
    const url = window.location.href.toLowerCase();
    const isVideoPage = 
      (url.includes('youtube.com/watch') && url.includes('v=')) ||
      (url.includes('vimeo.com/') && /vimeo\.com\/\d+/.test(url)) ||
      (url.includes('dailymotion.com/video/')) ||
      (url.includes('twitch.tv/videos/'));

    let content;
    if (isVideoPage) {
      console.log("Extracting video information...");
      content = extractVideoInfo();
      
      // Ensure we have enough content to process
      if (!content.title || content.title.length < 10) {
        console.log("Video title too short or missing");
        return;
      }
    } else {
      console.log("Extracting article content...");
      // Clone the document to avoid modifying the original
      const documentClone = document.cloneNode(true);
      
      // Create Readability instance
      const article = new Readability(documentClone, {
        charThreshold: 500,
        classesToPreserve: ['highlight', 'important'],
        url: window.location.href
      }).parse();

      if (!article || !article.textContent || article.textContent.trim().length < 200) {
        console.log("No substantial article content found on this page");
        return;
      }

      content = {
        url: window.location.href,
        title: article.title || document.title,
        textContent: article.textContent,
        excerpt: article.excerpt,
        siteName: article.siteName,
        byline: article.byline,
        type: 'ARTICLE'
      };
    }

    console.log("✅ Content extracted successfully:", {
      title: content.title,
      type: content.type,
      length: content.textContent.length,
      excerpt: content.excerpt?.substring(0, 100) + '...'
    });

    // Send to background script for AI processing
    console.log("📤 Sending content to AI background script...");
    chrome.runtime.sendMessage({
      action: "summarize",
      article: content
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.log("❌ Extension not available:", chrome.runtime.lastError.message);
      } else {
        console.log("✅ AI processing started:", response);
      }
    });

  } catch (error) {
    console.error("Error extracting content:", error);
  } finally {
    isProcessing = false;
  }
}

// Debounce function to avoid excessive processing
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Debounced version of extractArticleContent
const debouncedExtract = debounce(extractArticleContent, 2000);

// Main execution
function main() {
  // Wait for page to be fully loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (isArticlePage()) {
        debouncedExtract();
      }
    });
  } else {
    if (isArticlePage()) {
      debouncedExtract();
    }
  }
}

// Listen for navigation events (for SPAs)
let currentUrl = window.location.href;
const observer = new MutationObserver(() => {
  if (window.location.href !== currentUrl) {
    currentUrl = window.location.href;
    lastProcessedUrl = null; // Reset to allow processing of new URL
    setTimeout(() => {
      if (isArticlePage()) {
        debouncedExtract();
      }
    }, 1000);
  }
});

observer.observe(document, { subtree: true, childList: true });

// Listen for popstate events (back/forward navigation)
window.addEventListener('popstate', () => {
  lastProcessedUrl = null;
  setTimeout(() => {
    if (isArticlePage()) {
      debouncedExtract();
    }
  }, 1000);
});

// Start processing
main();

// Listen for messages from popup or background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractNow") {
    extractArticleContent();
    sendResponse({ success: true });
  }
}); 